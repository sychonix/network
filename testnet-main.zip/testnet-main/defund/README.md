<h3><p style="font-size:14px" align="right">Founder :
<a href="https://discord.gg/nodexcapital" target="_blank">NodeX Capital Discord Community</a></p></h3>
<h3><p style="font-size:14px" align="right">Visit Our Website :
<a href="https://discord.gg/nodexcapital" target="_blank">NodeX Capital Official</a></p></h3>
<h3><p style="font-size:14px" align="right">Hetzner :
<a href="https://hetzner.cloud/?ref=bMTVi7dcwSgA" target="_blank">Deploy Hetzner VPS Get 20€ Bonus!</a></h3>
<hr>

<p align="center">
  <img height="100" height="auto" src="https://user-images.githubusercontent.com/50621007/171904810-664af00a-e78a-4602-b66b-20bfd874fa82.png">
</p>

# Defund Testnet | Chain ID : defund-private-4

### Official Documentation:
>- [Validator setup instructions](https://github.com/defund-labs/defund/blob/main/testnet/private/validators.md)


### Explorer
>- https://explorer.nodexcapital.com/defund

### Automatic Installer
You can setup your Defund fullnode in few minutes by using automated script below.
```
wget -O defund.sh https://raw.githubusercontent.com/nodexcapital/testnet/main/defund/defund.sh && chmod +x defund.sh && ./defund.sh
```
### Public Endpoint

>- API : https://api.defund.nodexcapital.com
>- RPC : https://rpc.defund.nodexcapital.com
>- gRPC : https://grpc.defund.nodexcapital.com
>- gRPC Web : https://grpc-web.defund.nodexcapital.com

### Snapshot (Update every 5 hours)
```
COMING SOON
```

### State Sync
```
COMING SOON
```

### Live Peers
```
COMING SOON
```
### Addrbook (Update every hour)
```
COMING SOON
```
### Genesis
```
COMING SOON
```