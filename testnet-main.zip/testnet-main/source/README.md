<h3><p style="font-size:14px" align="right">Founder :
<a href="https://discord.gg/nodexcapital" target="_blank">NodeX Capital Discord Community</a></p></h3>
<h3><p style="font-size:14px" align="right">Visit Our Website :
<a href="https://discord.gg/nodexcapital" target="_blank">NodeX Capital Official</a></p></h3>
<hr>

<p align="center">
  <img height="100" height="auto" src="https://user-images.githubusercontent.com/50621007/189353069-b9796464-574d-4903-b639-163fd0191ec9.png">
</p>

# Source Testnet | Chain ID : sourcechain-testnet

### Official Documentation:
>- [Validator setup instructions](https://github.com/obajay/nodes-Guides/tree/main/Source)

### Explorer:
>-  https://explorer.nodexcapital.com/source

### Automatic Installer
You can setup your Source fullnode in few minutes by using automated script below.
```
wget -O source.sh https://raw.githubusercontent.com/nodexcapital/testnet/main/source/source.sh && chmod +x source.sh && ./source.sh
```
### Public Endpoint

>- API : https://api.source.nodexcapital.com
>- RPC : https://rpc.source.nodexcapital.com
>- gRPC : https://grpc.source.nodexcapital.com
>- gRPC Web : https://grpc-web.source.nodexcapital.com

### Snapshot (Update every 5 hours)
```
COMING SOON
```

### State Sync
```
COMING SOON
```

### Live Peers
```
COMING SOON
```
### Addrbook (Update every hour)
```
COMING SOON
```
### Genesis
```
COMING SOON
```