<h3><p style="font-size:14px" align="right">Founder :
<a href="https://discord.gg/nodexcapital" target="_blank">NodeX Capital Discord Community</a></p></h3>
<h3><p style="font-size:14px" align="right">Visit Our Website :
<a href="https://discord.gg/nodexcapital" target="_blank">NodeX Capital Official</a></p></h3>
<h3><p style="font-size:14px" align="right">Hetzner :
<a href="https://hetzner.cloud/?ref=bMTVi7dcwSgA" target="_blank">Deploy Hetzner VPS Get 20€ Bonus!</a></h3>
<hr>

<p align="center">
  <img height="100" height="auto" src="https://nodejumper.io/assets/img/chain/gitopia.webp">
</p>

# Terp Network Testnet | Chain ID : athena-3

### Community Documentation:
>- [Validator Setup Instructions](https://nodejumper.io/terpnetwork-testnet/installation)

### Explorer:
>-  https://explorer.nodexcapital.com/terp

### Automatic Installer
You can setup your Terp fullnode in few minutes by using automated script below.
```
wget -O terp.sh https://raw.githubusercontent.com/nodexcapital/testnet/main/terp/terp.sh && chmod +x terp.sh && ./terp.sh
```
### Public Endpoint

>- API : https://api.terp.nodexcapital.com
>- RPC : https://rpc.terp.nodexcapital.com
>- gRPC : https://grpc.terp.nodexcapital.com
>- gRPC Web : https://grpc-web.terp.nodexcapital.com

### Snapshot (Update every 5 hours)
```
COMING SOON
```

### State Sync
```
COMING SOON
```

### Live Peers
```
COMING SOON
```
### Addrbook (Update every hour)
```
COMING SOON
```
### Genesis
```
COMING SOON
```