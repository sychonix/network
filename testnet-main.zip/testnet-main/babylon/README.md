<h3><p style="font-size:14px" align="right">Founder :
<a href="https://discord.gg/nodexcapital" target="_blank">NodeX Capital Discord Community</a></p></h3>
<h3><p style="font-size:14px" align="right">Visit Our Website :
<a href="https://discord.gg/nodexcapital" target="_blank">NodeX Capital Official</a></p></h3>
<h3><p style="font-size:14px" align="right">Hetzner :
<a href="https://hetzner.cloud/?ref=bMTVi7dcwSgA" target="_blank">Deploy Hetzner VPS Get 20€ Bonus!</a></h3>
<hr>

<p align="center">
  <img height="100" height="auto" src="https://nodejumper.io/assets/img/chain/babylon.webp">
</p>

# Babylon Testnet | Chain ID : bbn-test1

### Community Documentation:
>- [Validator Setup Instructions](https://nodejumper.io/babylon-testnet)

### Explorer:
>-  https://explorer.nodexcapital.com/babylon

### Automatic Installer
You can setup your Babylon fullnode in few minutes by using automated script below.
```
wget -O babylon.sh https://raw.githubusercontent.com/nodexcapital/testnet/main/babylon/babylon.sh && chmod +x babylon.sh && ./babylon.sh
```
### Public Endpoint

>- API : https://api.babylon.nodexcapital.com
>- RPC : https://rpc.babylon.nodexcapital.com
>- gRPC : https://grpc.babylon.nodexcapital.com
>- gRPC Web : https://grpc-web.babylon.nodexcapital.com

### Snapshot (Update every 5 hours)
```
COMING SOON
```

### State Sync
```
COMING SOON
```

### Live Peers
```
COMING SOON
```
### Addrbook (Update every hour)
```
COMING SOON
```
### Genesis
```
COMING SOON
```