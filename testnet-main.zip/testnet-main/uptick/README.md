<h3><p style="font-size:14px" align="right">Founder :
<a href="https://discord.gg/nodexcapital" target="_blank">NodeX Capital Discord Community</a></p></h3>
<h3><p style="font-size:14px" align="right">Visit Our Website :
<a href="https://discord.gg/nodexcapital" target="_blank">NodeX Capital Official</a></p></h3>
<h3><p style="font-size:14px" align="right">Hetzner :
<a href="https://hetzner.cloud/?ref=bMTVi7dcwSgA" target="_blank">Deploy Hetzner VPS Get 20€ Bonus!</a></h3>
<hr>

<p align="center">
  <img height="100" height="auto" src="https://user-images.githubusercontent.com/50621007/171044333-016e348d-1d96-4d00-8dce-f7de45aa9f84.png">
</p>

# Uptick Testnet | Chain ID : uptick_7000-2

Official Documentation:
>- [Validator setup instructions](https://docs.uptick.network/testnet/)

Explorer:
>-  https://explorer.nodexcapital.com/uptick


### Automatic Installer
You can setup your Uptick fullnode in few minutes by using automated script below.
```
wget -O uptick.sh https://raw.githubusercontent.com/nodexcapital/testnet/main/uptick/uptick.sh && chmod +x uptick.sh && ./uptick.sh
```
### Public Endpoint

>- API : https://api.uptick.nodexcapital.com
>- RPC : https://rpc.uptick.nodexcapital.com
>- gRPC : https://grpc.uptick.nodexcapital.com
>- gRPC Web : https://grpc-web.uptick.nodexcapital.com

### Snapshot (Update every 5 hours)
```
COMING SOON
```

### State Sync
```
COMING SOON
```

### Live Peers
```
COMING SOON
```
### Addrbook (Update every hour)
```
COMING SOON
```
### Genesis
```
COMING SOON
```