<h3><p style="font-size:14px" align="right">Founder :
<a href="https://discord.gg/nodexcapital" target="_blank">NodeX Capital Discord Community</a></p></h3>
<h3><p style="font-size:14px" align="right">Visit Our Website :
<a href="https://discord.gg/nodexcapital" target="_blank">NodeX Capital Official</a></p></h3>
<h3><p style="font-size:14px" align="right">Hetzner :
<a href="https://hetzner.cloud/?ref=bMTVi7dcwSgA" target="_blank">Deploy Hetzner VPS Get 20€ Bonus!</a></h3>
<hr>

<p align="center">
  <img height="100" height="auto" src="https://raw.githubusercontent.com/Nodeist/Kurulumlar/main/logos/sge.png">
</p>

# SGE Network Testnet | Chain ID : sge-testnet-1

### Community Documentation:
>- https://nodeist.net/t/Sge/

### Explorer:
>-  https://explorer.nodexcapital.com/sigma

### Automatic Installer
You can setup your SGE Network fullnode in few minutes by using automated script below.
```
wget -O sge.sh https://raw.githubusercontent.com/nodexcapital/testnet/main/sigma/sge.sh && chmod +x sge.sh && ./sge.sh
```
### Public Endpoint

>- API : https://api.sge.nodexcapital.com
>- RPC : https://rpc.sge.nodexcapital.com
>- gRPC : https://grpc.sge.nodexcapital.com
>- gRPC Web : https://grpc-web.sge.nodexcapital.com

### Snapshot (Update every 5 hours)
```
COMING SOON
```

### State Sync
```
COMING SOON
```

### Live Peers
```
COMING SOON
```
### Addrbook (Update every hour)
```
COMING SOON
```
### Genesis
```
COMING SOON
```